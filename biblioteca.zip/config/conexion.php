<?
$host="bxaxn6wlabfwelxj5hfo-mysql.services.clever-cloud.com";
$bd="bxaxn6wlabfwelxj5hfo";
$user="utbofx2gjlynwlt2";
$pwd="ZLyqGO1mmqUQ9FtyzUkC";
$con=mysqli_connect($host,$user,$pwd,$bd) or
    die(" Problemas en la conexión");
?>